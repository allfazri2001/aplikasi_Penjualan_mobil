import tkinter as tk
from views.main_view import MainView

class CarSalesApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Car Sales Management System")
        self.root.geometry("800x600")
        self.main_view = MainView(self.root)
        self.main_view.pack(fill="both", expand=True)

def main():
    root = tk.Tk()
    app = CarSalesApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
