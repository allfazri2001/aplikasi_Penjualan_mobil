from database.db_handler import DBHandler

class CarController:
    def __init__(self):
        self.db = DBHandler()

    def add_car(self, brand, model, price, stock):
        self.db.add_car(brand, model, price, stock)

    def get_all_cars(self):
        return self.db.get_all_cars()

    def update_car(self, car_id, brand, model, price, stock):
        self.db.update_car(car_id, brand, model, price, stock)

    def delete_car(self, car_id):
        self.db.delete_car(car_id)
