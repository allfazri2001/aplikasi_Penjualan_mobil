from database.db_handler import DBHandler

class CustomerController:
    def __init__(self):
        self.db = DBHandler()

    def add_customer(self, name, phone, email):
        self.db.add_customer(name, phone, email)

    def get_all_customers(self):
        return self.db.get_all_customers()

    def delete_customer(self, customer_id):
        self.db.delete_customer(customer_id)
