from database.db_handler import DBHandler

class SalesController:
    def __init__(self):
        self.db = DBHandler()

    def add_sale_with_stock_validation(self, car_id, customer_id, date, total_price):
        car_stock = self.db.get_car_stock(car_id)
        if car_stock > 0:
            self.db.reduce_car_stock(car_id)
            self.db.add_sale(car_id, customer_id, date, total_price)
        else:
            raise ValueError("Stock mobil tidak mencukupi!")

    def get_all_sales(self):
        return self.db.get_all_sales()

    def delete_sale(self, sale_id):
        self.db.delete_sale(sale_id)
