class Sale:
    def __init__(self, sale_id, car_id, customer_id, date, total_price):
        self.sale_id = sale_id
        self.car_id = car_id
        self.customer_id = customer_id
        self.date = date
        self.total_price = total_price
