import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from controllers.car_controller import CarController

class CarView(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.title("Manage Cars")
        self.geometry("800x400")
        self.controller = CarController()

        # Table for displaying cars
        self.car_table = ttk.Treeview(self, columns=("ID", "Brand", "Model", "Price", "Stock"), show="headings")
        self.car_table.heading("ID", text="ID")
        self.car_table.heading("Brand", text="Brand")
        self.car_table.heading("Model", text="Model")
        self.car_table.heading("Price", text="Price")
        self.car_table.heading("Stock", text="Stock")
        self.car_table.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        # Form inputs
        self.brand_entry = ttk.Entry(self)
        self.brand_entry.grid(row=1, column=1, padx=10, pady=5)
        tk.Label(self, text="Brand").grid(row=1, column=0)

        self.model_entry = ttk.Entry(self)
        self.model_entry.grid(row=2, column=1, padx=10, pady=5)
        tk.Label(self, text="Model").grid(row=2, column=0)

        self.price_entry = ttk.Entry(self)
        self.price_entry.grid(row=3, column=1, padx=10, pady=5)
        tk.Label(self, text="Price").grid(row=3, column=0)

        self.stock_entry = ttk.Entry(self)
        self.stock_entry.grid(row=4, column=1, padx=10, pady=5)
        tk.Label(self, text="Stock").grid(row=4, column=0)

        # Buttons
        add_button = ttk.Button(self, text="Add Car", command=self.add_car)
        add_button.grid(row=5, column=0, padx=10, pady=10)

        update_button = ttk.Button(self, text="Update Selected", command=self.update_car)
        update_button.grid(row=5, column=1, padx=10, pady=10)

        delete_button = ttk.Button(self, text="Delete Selected", command=self.delete_car)
        delete_button.grid(row=5, column=2, padx=10, pady=10)

        self.load_cars()

    def load_cars(self):
        for row in self.car_table.get_children():
            self.car_table.delete(row)
        cars = self.controller.get_all_cars()
        for car in cars:
            self.car_table.insert("", "end", values=car)

    def add_car(self):
        try:
            brand = self.brand_entry.get()
            model = self.model_entry.get()
            price = float(self.price_entry.get())
            stock = int(self.stock_entry.get())
            self.controller.add_car(brand, model, price, stock)
            self.load_cars()
            messagebox.showinfo("Success", "Car added successfully!")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def update_car(self):
        selected_item = self.car_table.selection()
        if selected_item:
            car_id = self.car_table.item(selected_item)['values'][0]
            brand = self.brand_entry.get()
            model = self.model_entry.get()
            price = float(self.price_entry.get())
            stock = int(self.stock_entry.get())
            self.controller.update_car(car_id, brand, model, price, stock)
            self.load_cars()

    def delete_car(self):
        selected_item = self.car_table.selection()
        if selected_item:
            car_id = self.car_table.item(selected_item)['values'][0]
            self.controller.delete_car(car_id)
            self.load_cars()
