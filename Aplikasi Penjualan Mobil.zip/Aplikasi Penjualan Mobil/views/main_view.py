import tkinter as tk
from tkinter import ttk
from views.car_view import CarView
from views.customer_view import CustomerView
from views.sales_view import SalesView

class MainView(tk.Frame):
    def __init__(self, root):
        super().__init__(root)
        title_label = tk.Label(self, text="Car Sales Management System", font=("Arial", 24))
        title_label.pack(pady=20)

        car_button = ttk.Button(self, text="Manage Cars", command=self.manage_cars)
        car_button.pack(pady=10)

        customer_button = ttk.Button(self, text="Manage Customers", command=self.manage_customers)
        customer_button.pack(pady=10)

        sales_button = ttk.Button(self, text="View Sales", command=self.view_sales)
        sales_button.pack(pady=10)

        exit_button = ttk.Button(self, text="Exit", command=root.quit)
        exit_button.pack(pady=10)

    def manage_cars(self):
        CarView(self.master)

    def manage_customers(self):
        CustomerView(self.master)

    def view_sales(self):
        SalesView(self.master)
