import tkinter as tk
from tkinter import ttk
from controllers.sales_controller import SalesController
from datetime import datetime
from tkinter import messagebox

class SalesView(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.title("Sales Report")
        self.geometry("800x400")
        self.controller = SalesController()

        self.sales_table = ttk.Treeview(self, columns=("ID", "Car", "Customer", "Date", "Total Price"), show="headings")
        self.sales_table.heading("ID", text="ID")
        self.sales_table.heading("Car", text="Car")
        self.sales_table.heading("Customer", text="Customer")
        self.sales_table.heading("Date", text="Date")
        self.sales_table.heading("Total Price", text="Total Price")
        self.sales_table.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        self.car_id_entry = ttk.Entry(self)
        self.car_id_entry.grid(row=1, column=1, padx=10, pady=5)
        tk.Label(self, text="Car ID").grid(row=1, column=0)

        self.customer_id_entry = ttk.Entry(self)
        self.customer_id_entry.grid(row=2, column=1, padx=10, pady=5)
        tk.Label(self, text="Customer ID").grid(row=2, column=0)

        self.total_price_entry = ttk.Entry(self)
        self.total_price_entry.grid(row=3, column=1, padx=10, pady=5)
        tk.Label(self, text="Total Price").grid(row=3, column=0)

        add_button = ttk.Button(self, text="Add Sale", command=self.add_sale)
        add_button.grid(row=4, column=0, padx=10, pady=10)

        delete_button = ttk.Button(self, text="Delete Selected", command=self.delete_sale)
        delete_button.grid(row=4, column=1, padx=10, pady=10)

        self.load_sales()

    def load_sales(self):
        for row in self.sales_table.get_children():
            self.sales_table.delete(row)
        sales = self.controller.get_all_sales()
        for sale in sales:
            self.sales_table.insert("", "end", values=sale)

    def add_sale(self):
        try:
            car_id = int(self.car_id_entry.get())
            customer_id = int(self.customer_id_entry.get())
            total_price = float(self.total_price_entry.get())
            date = datetime.now().strftime("%Y-%m-%d")
            self.controller.add_sale_with_stock_validation(car_id, customer_id, date, total_price)
            self.load_sales()
            messagebox.showinfo("Success", "Penjualan berhasil ditambahkan!")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def delete_sale(self):
        selected_item = self.sales_table.selection()
        if selected_item:
            sale_id = self.sales_table.item(selected_item)['values'][0]
            self.controller.delete_sale(sale_id)
            self.load_sales()
