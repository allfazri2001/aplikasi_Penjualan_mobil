import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from controllers.customer_controller import CustomerController

class CustomerView(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.title("Manage Customers")
        self.geometry("800x400")
        self.controller = CustomerController()

        # Table for displaying customers
        self.customer_table = ttk.Treeview(self, columns=("ID", "Name", "Phone", "Email"), show="headings")
        self.customer_table.heading("ID", text="ID")
        self.customer_table.heading("Name", text="Name")
        self.customer_table.heading("Phone", text="Phone")
        self.customer_table.heading("Email", text="Email")
        self.customer_table.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        # Form inputs
        self.name_entry = ttk.Entry(self)
        self.name_entry.grid(row=1, column=1, padx=10, pady=5)
        tk.Label(self, text="Name").grid(row=1, column=0)

        self.phone_entry = ttk.Entry(self)
        self.phone_entry.grid(row=2, column=1, padx=10, pady=5)
        tk.Label(self, text="Phone").grid(row=2, column=0)

        self.email_entry = ttk.Entry(self)
        self.email_entry.grid(row=3, column=1, padx=10, pady=5)
        tk.Label(self, text="Email").grid(row=3, column=0)

        # Buttons
        add_button = ttk.Button(self, text="Add Customer", command=self.add_customer)
        add_button.grid(row=4, column=0, padx=10, pady=10)

        delete_button = ttk.Button(self, text="Delete Selected", command=self.delete_customer)
        delete_button.grid(row=4, column=1, padx=10, pady=10)

        self.load_customers()

    def load_customers(self):
        for row in self.customer_table.get_children():
            self.customer_table.delete(row)
        customers = self.controller.get_all_customers()
        for customer in customers:
            self.customer_table.insert("", "end", values=customer)

    def add_customer(self):
        try:
            name = self.name_entry.get()
            phone = self.phone_entry.get()
            email = self.email_entry.get()
            self.controller.add_customer(name, phone, email)
            self.load_customers()
            messagebox.showinfo("Success", "Customer added successfully!")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def delete_customer(self):
        selected_item = self.customer_table.selection()
        if selected_item:
            customer_id = self.customer_table.item(selected_item)['values'][0]
            self.controller.delete_customer(customer_id)
            self.load_customers()
