import sqlite3

class DBHandler:
    def __init__(self, db_name="car_sales.db"):
        # Connect to the database
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        # Create tables if not already created
        self.create_tables()

    def create_tables(self):
        # Table for cars
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS cars (
            car_id INTEGER PRIMARY KEY AUTOINCREMENT,
            brand TEXT NOT NULL,
            model TEXT NOT NULL,
            price REAL NOT NULL,
            stock INTEGER NOT NULL
        )''')

        # Table for customers
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS customers (
            customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT NOT NULL
        )''')

        # Table for sales
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS sales (
            sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
            car_id INTEGER NOT NULL,
            customer_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            total_price REAL NOT NULL,
            FOREIGN KEY(car_id) REFERENCES cars(car_id),
            FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
        )''')
        self.conn.commit()

    # CRUD for Cars
    def add_car(self, brand, model, price, stock):
        self.cursor.execute('''
        INSERT INTO cars (brand, model, price, stock)
        VALUES (?, ?, ?, ?)
        ''', (brand, model, price, stock))
        self.conn.commit()

    def get_all_cars(self):
        self.cursor.execute('SELECT * FROM cars')
        return self.cursor.fetchall()

    def update_car(self, car_id, brand, model, price, stock):
        self.cursor.execute('''
        UPDATE cars
        SET brand = ?, model = ?, price = ?, stock = ?
        WHERE car_id = ?
        ''', (brand, model, price, stock, car_id))
        self.conn.commit()

    def delete_car(self, car_id):
        self.cursor.execute('DELETE FROM cars WHERE car_id = ?', (car_id,))
        self.conn.commit()

    # CRUD for Customers
    def add_customer(self, name, phone, email):
        self.cursor.execute('''
        INSERT INTO customers (name, phone, email)
        VALUES (?, ?, ?)
        ''', (name, phone, email))
        self.conn.commit()

    def get_all_customers(self):
        self.cursor.execute('SELECT * FROM customers')
        return self.cursor.fetchall()

    def delete_customer(self, customer_id):
        self.cursor.execute('DELETE FROM customers WHERE customer_id = ?', (customer_id,))
        self.conn.commit()

    # CRUD for Sales
    def add_sale(self, car_id, customer_id, date, total_price):
        self.cursor.execute('''
        INSERT INTO sales (car_id, customer_id, date, total_price)
        VALUES (?, ?, ?, ?)
        ''', (car_id, customer_id, date, total_price))
        self.conn.commit()

    def get_all_sales(self):
        self.cursor.execute('''
        SELECT sales.sale_id, cars.brand, customers.name, sales.date, sales.total_price
        FROM sales
        INNER JOIN cars ON sales.car_id = cars.car_id
        INNER JOIN customers ON sales.customer_id = customers.customer_id
        ''')
        return self.cursor.fetchall()

    def delete_sale(self, sale_id):
        self.cursor.execute('DELETE FROM sales WHERE sale_id = ?', (sale_id,))
        self.conn.commit()

    # Reduce stock of a car when sold
    def reduce_car_stock(self, car_id, quantity=1):
        self.cursor.execute('''
        UPDATE cars
        SET stock = stock - ?
        WHERE car_id = ? AND stock >= ?
        ''', (quantity, car_id, quantity))
        self.conn.commit()

    # Get stock for a specific car
    def get_car_stock(self, car_id):
        self.cursor.execute('SELECT stock FROM cars WHERE car_id = ?', (car_id,))
        result = self.cursor.fetchone()
        return result[0] if result else None

    # Close the database connection
    def close_connection(self):
        self.conn.close()
